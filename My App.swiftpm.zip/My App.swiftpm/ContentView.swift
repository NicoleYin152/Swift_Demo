import SwiftUI

struct ContentView: View {
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var formSubmitted = false
    @State private var showingSuccessView = false
    @State private var passwordVisible = false  // 控制第一个密码字段的可见性
    @State private var confirmPasswordVisible = false 
    
    var body: some View {
        NavigationStack {
            Form {
                Section(header: Text("登录")) {
                    TextField("邮箱", text: $email)
                        .autocapitalization(.none)
                        .keyboardType(.emailAddress)
                    if !email.isValidEmail() && formSubmitted {
                        Text("请输入正确的邮箱格式 -- abcd@gmail.com")
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                    
                    PasswordField(title: "密码", password: $password, isVisible: $passwordVisible)
                    if (!isPasswordValid && formSubmitted) || (!passwordFocused && password.count > 0) {
                        Text("密码长度至少为8且包含字母和数字")
                            .foregroundColor(formSubmitted ? .red : .gray)
                            .font(.caption)
                    }
                    
                    PasswordField( title: "确认密码", password: $confirmPassword, isVisible: $confirmPasswordVisible)
                    if confirmPassword != password && formSubmitted {
                        Text("您输入的密码不一致")
                            .foregroundColor(.red)
                            .font(.caption)
                    }
                    
                    Button("登录") {
                        formSubmitted = true
                        if isInputValid {
                            showingSuccessView = true  // 验证成功后更新状态，以触发导航
                        }
                    }
                    .disabled(email.isEmpty || password.isEmpty || confirmPassword.isEmpty)
                    .foregroundColor((email.isEmpty || password.isEmpty || confirmPassword.isEmpty) ? .gray : .green)
                }
            }
            .navigationTitle("登录表单")
            .navigationDestination(isPresented: $showingSuccessView) {
                SuccessView()
            } 
        }
    }
    
    var isPasswordValid: Bool {
        let hasMinLength = password.count >= 8
        let containsLetters = password.rangeOfCharacter(from: .letters) != nil
        let containsDigits = password.rangeOfCharacter(from: .decimalDigits) != nil
        return hasMinLength && containsLetters && containsDigits
    }

    
    var isInputValid: Bool {
        email.isValidEmail() && isPasswordValid && confirmPassword == password
    }
    
    var passwordFocused: Bool {
        // 实现该属性以检测密码输入框是否被聚焦
        return false
    }
}

struct PasswordField: View {
    var title: String
    @Binding var password: String
    @Binding var isVisible: Bool  // 将 isVisible 改为 @Binding 以便可以从外部控制
    
    var body: some View {
        HStack {
            if isVisible {
                TextField(title, text: $password)
            } else {
                SecureField(title, text: $password)
            }
            Button(action: {
                isVisible.toggle()  // 现在这里可以正常工作，因为 isVisible 是一个绑定的状态
            }) {
                Image(systemName: isVisible ? "eye.slash.fill" : "eye.fill")
                    .foregroundColor(.gray)
            }
        }
    }
}


struct SuccessView: View {
    var body: some View {
        Text("成功登录!")
            .font(.largeTitle)
            .padding()
    }
}

extension String {
    func isValidEmail() -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        return NSPredicate(format: "SELF MATCHES %@", emailRegex).evaluate(with: self)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

